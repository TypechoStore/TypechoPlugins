### TleDaShangForTypecho打赏插件
---

一款Typecho版本的可为文章打赏的插件，并且提供在线乞讨的独立页面，支持三合一转账二维码支付和有赞支付。

程序有可能会遇到bug不改版本号直接修改代码的时候，所以扫描以下二维码关注公众号“同乐儿”，可直接与作者二呆产生联系，不再为bug烦恼，随时随地解决问题。

#### 使用方法：
第一步：下载本插件，放在 `usr/plugins/` 目录中（插件文件夹名必须为TleDaShang）；<br />
第二步：激活插件；<br />
第三步：填写配置；<br />
第四步：完成。

#### 使用注意：
此插件使用php5.6编写，php7.0“可能”会报语法错误，建议使用php5.6，因为7.0实在太高了=_=!

#### 与我联系：
作者：二呆<br />
网站：http://www.tongleer.com/<br />
Github：https://github.com/muzishanshi/TleDaShangForTypecho

#### 更新记录：
2019-03-22

	V1.0.2	修复了因cdn.bootcss.com中JS静态资源不可访问导致的js失效的问题。
	
2018-10-26
	
	V1.0.1	第一版本实现