### TleDaShangForTypecho打赏插件
---

一款Typecho版本的可为文章打赏的插件，并且提供在线乞讨的独立页面，支持三合一转账二维码支付和payjs微信支付。

程序有可能会遇到bug不改版本号直接修改代码的时候，所以扫描以下二维码关注公众号“同乐儿”，可直接与作者二呆产生联系，不再为bug烦恼，随时随地解决问题。

#### 使用方法：
第一步：下载本插件，放在 `usr/plugins/` 目录中（插件文件夹名必须为TleDaShang）；

第二步：激活插件；

第三步：填写配置；

第四步：完成。

#### 版本推荐：
此插件使用php5.6+Typecho正式版开发。

#### 与我联系：
作者：二呆

1元入群：http://joke.tongleer.com/333.html

网站：http://www.tongleer.com/

Github：https://github.com/muzishanshi/TleDaShangForTypecho

#### 更新记录：
2019-04-06

	V1.0.3	新增payjs微信支付，可通过自己的微信直接到账银行卡，并删掉有赞支付。
	
2019-03-22

	V1.0.2	修复了因cdn.bootcss.com中JS静态资源不可访问导致的js失效的问题。
	
2018-10-26
	
	V1.0.1	第一版本实现