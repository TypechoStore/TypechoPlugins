<?php
/**
 * TypechoStore For Typecho 应用商店插件为用户提供快捷安装Typecho模板、插件的渠道。
 * @package Typecho应用商店
 * @author 二呆
 * @version 1.0.1
 * @link http://www.tongleer.com/
 * @date 2018-12-24
 */

class TypechoStore_Plugin implements Typecho_Plugin_Interface{
    // 激活插件
    public static function activate(){
		$db = Typecho_Db::get();
		self::funWriteAdminPage($db,'shop.php');
		self::funWriteAdminPage($db,'shop_header.php');
		self::funWriteAdminPage($db,'shop_sidebar.php');
		self::funWriteAdminPage($db,'shop_index.php');
		self::funWriteAdminPage($db,'shop_footer.php');
		self::funWriteAdminPage($db,'shop_templates.php');
		self::funWriteAdminPage($db,'shop_plugins.php');
		self::funWriteAdminPage($db,'shop_404.php');
		Typecho_Plugin::factory(substr(__TYPECHO_ADMIN_DIR__,1).'menu.php')->navBar = array('TypechoStore_Plugin', 'shop');
        return _t('插件已经激活，需先配置插件信息！');
    }

    // 禁用插件
    public static function deactivate(){
		@unlink(dirname(__FILE__).'/../../..'.__TYPECHO_ADMIN_DIR__.'shop.php');
		@unlink(dirname(__FILE__).'/../../..'.__TYPECHO_ADMIN_DIR__.'shop_header.php');
		@unlink(dirname(__FILE__).'/../../..'.__TYPECHO_ADMIN_DIR__.'shop_sidebar.php');
		@unlink(dirname(__FILE__).'/../../..'.__TYPECHO_ADMIN_DIR__.'shop_index.php');
		@unlink(dirname(__FILE__).'/../../..'.__TYPECHO_ADMIN_DIR__.'shop_footer.php');
		@unlink(dirname(__FILE__).'/../../..'.__TYPECHO_ADMIN_DIR__.'shop_templates.php');
		@unlink(dirname(__FILE__).'/../../..'.__TYPECHO_ADMIN_DIR__.'shop_plugins.php');
		@unlink(dirname(__FILE__).'/../../..'.__TYPECHO_ADMIN_DIR__.'shop_404.php');
        return _t('插件已被禁用');
    }

    // 插件配置面板
    public static function config(Typecho_Widget_Helper_Form $form){
		echo "<style>
		body{background-color:#F5F5F5}@media screen and (min-device-width:1024px){::-webkit-scrollbar-track{background-color:rgba(255,255,255,0)}::-webkit-scrollbar{width:6px;background-color:rgba(255,255,255,0)}::-webkit-scrollbar-thumb{border-radius:3px;background-color:rgba(193,193,193,1)}}.typecho-head-nav{}#typecho-nav-list .focus .parent a,#typecho-nav-list .parent a:hover,#typecho-nav-list .root:hover .parent a{background:RGBA(255,255,255,0);}#typecho-nav-list{display:block}.typecho-head-nav .operate a{border:0;color:rgba(255,255,255,.6)}.typecho-head-nav .operate a:focus,.typecho-head-nav .operate a:hover{color:rgba(255,255,255,.8);background-color:#673AB7;outline:0}.body.container{min-width:100%!important;padding:0}.row{margin:0}.col-mb-12{padding:0!important}.typecho-page-title{height:100px;padding:10px 40px 20px 40px;background-color:#673AB7;color:#FFF;font-size:24px}.typecho-option-tabs{padding:0;margin:0;height:60px;background-color:#512DA8;margin-bottom:40px!important;padding-left:25px}.typecho-option-tabs li{margin:0;border:none;float:left;position:relative;display:block;text-align:center;font-weight:500;font-size:14px;text-transform:uppercase}.typecho-option-tabs a{height:auto;border:0;color:rgba(255,255,255,.6);background-color:rgba(255,255,255,0)!important;padding:17px 24px}.typecho-option-tabs a:hover{color:rgba(255,255,255,.8)}.message{background-color:#673AB7!important;color:#fff}.success{background-color:#673AB7;color:#fff}.current{background-color:#FFF;height:4px;padding:0!important;bottom:0}.current a{color:#FFF}input[type=text],textarea{border:none;border-bottom:1px solid rgba(0,0,0,.6);outline:0;border-radius:0}.typecho-option span{margin-right:0}.typecho-option-submit{position:fixed;right:32px;bottom:32px}.typecho-option-submit button{float:right;background:#00BCD4;box-shadow:0 2px 2px 0 rgba(0,0,0,.14),0 3px 1px -2px rgba(0,0,0,.2),0 1px 5px 0 rgba(0,0,0,.12);color:#FFF}.typecho-page-main .typecho-option textarea{height:149px}.typecho-option label.typecho-label{font-weight:500;margin-bottom:20px;margin-top:10px;font-size:16px;padding-bottom:5px;border-bottom:1px solid rgba(0,0,0,.2)}#use-intro{box-shadow:0 2px 2px 0 rgba(0,0,0,.14),0 3px 1px -2px rgba(0,0,0,.2),0 1px 5px 0 rgba(0,0,0,.12);background-color:#fff;margin:8px;padding:8px;padding-left:20px;margin-bottom:40px}.typecho-foot{padding:16px 40px;color:#9e9e9e;margin-top:80px}button,form{display:none}
		</style>";
		
		$text = new Typecho_Widget_Helper_Form_Element_Text('text', array("value"), "应用商店", _t('应用商店'));
        $form->addInput($text);
    }

    // 个人用户配置面板
    public static function personalConfig(Typecho_Widget_Helper_Form $form){
    }

    // 获得插件配置信息
    public static function getConfig(){
        return Typecho_Widget::widget('Widget_Options')->plugin('TypechoStore');
    }
	
	public static function shop(){
		$db = Typecho_Db::get();
		
		$queryUser= $db->select()->from('table.users')->where('uid = ?', Typecho_Cookie::get('__typecho_uid')); 
		$rowUser = $db->fetchRow($queryUser);
		if($rowUser["group"]!="administrator"){return;}
		
		$option=self::getConfig();
		$querySiteUrl= $db->select('value')->from('table.options')->where('name = ?', 'siteUrl'); 
		$rowSiteUrl = $db->fetchRow($querySiteUrl);
		echo '<a href="'.$rowSiteUrl["value"].__TYPECHO_ADMIN_DIR__.'shop.php">'.$option->text.'</a>';
    }
	
	/*公共方法：将页面写入管理目录*/
	public static function funWriteAdminPage($db,$filename){
		$path=dirname(__FILE__).'/../../..'.__TYPECHO_ADMIN_DIR__;
		if(!is_writable($path)){
			Typecho_Widget::widget('Widget_Notice')->set(_t('管理目录不可写，请更改目录权限。'), 'success');
		}
		if(!file_exists($path."/".$filename)){
			$regfile = @fopen(dirname(__FILE__).__TYPECHO_ADMIN_DIR__.$filename, "r") or die("不能读取".$filename."文件");
			$regtext=fread($regfile,filesize(dirname(__FILE__).__TYPECHO_ADMIN_DIR__.$filename));
			fclose($regfile);
			$regpage = fopen($path."/".$filename, "w") or die("不能写入".$filename."文件");
			fwrite($regpage, $regtext);
			fclose($regpage);
		}
	}
}