### Typecho应用商店
---

TypechoStore For Typecho 应用商店插件为用户提供快捷安装Typecho模板、插件的渠道。

#### 使用方法：
第一步：下载本插件，放在 `usr/plugins/` 目录中（插件文件夹名必须为TypechoStore）；<br />
第二步：激活插件；<br />
第三步：填写配置；<br />
第四步：完成。

#### 版本推荐：
php+mysql，推荐php5.6，以上版本可能也没问题，如有问题可联系作者。

#### 更新记录：
2018-24-24
	
	V1.0.1 发布