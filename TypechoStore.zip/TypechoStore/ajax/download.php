<?php
date_default_timezone_set('Asia/Shanghai');
include '../../../../config.inc.php';
require_once("../libs/ZipFolder.php");
$db = Typecho_Db::get();
$prefix = $db->getPrefix();
$options = Typecho_Widget::widget('Widget_Options');
$option=$options->plugin('TypechoStore');

$action = isset($_POST['action']) ? addslashes($_POST['action']) : '';

if($action=='downloadTemplate'){
	$cid = isset($_POST['cid']) ? addslashes($_POST['cid']) : '';
	$url = isset($_POST['url']) ? addslashes($_POST['url']) : '';
	$hasLogin = isset($_POST['hasLogin']) ? addslashes($_POST['hasLogin']) : '';
	$start = isset($_POST['start']) ? addslashes($_POST['start']) : '';
	
	$tmplatedir=__TYPECHO_ROOT_DIR__.__TYPECHO_THEME_DIR__."/";
	
	if($hasLogin==1){
		if($start==1){
			$zip = new ZipFolder;
			$arr=$zip->getFile($url,$tmplatedir,basename($url),1);
			if($arr){
				$result=$zip->unzip($tmplatedir.basename($url),$tmplatedir);
				if($result){
					$arr=array("code"=>100,"msg"=>"安装成功");
				}else{
					$arr=array("code"=>105,"msg"=>"安装失败，可再重试一次。");
				}
				@unlink($tmplatedir.basename($url));
				$db->query("update ".$prefix."contents set viewsNum=viewsNum+1 where cid=".$cid);
			}else{
				$arr=array("code"=>104,"msg"=>"下载失败");
			}
		}else{
			if(is_dir($tmplatedir.basename($url,".zip"))){
				$arr=array("code"=>102,"msg"=>"模板已存在");
			}else{
				$arr=array("code"=>103,"msg"=>"确定要下载吗？");
			}
		}
	}else{
		$arr=array("code"=>101,"msg"=>"登陆后获得该权限");
	}
	foreach ( $arr as $key => $value ) {  
		$arr[$key] = urlencode ( $value );  
	}  
	$json=json_encode($arr);
	echo urldecode($json);
}else if($action=='downloadPlugin'){
	$cid = isset($_POST['cid']) ? addslashes($_POST['cid']) : '';
	$url = isset($_POST['url']) ? addslashes($_POST['url']) : '';
	$hasLogin = isset($_POST['hasLogin']) ? addslashes($_POST['hasLogin']) : '';
	$start = isset($_POST['start']) ? addslashes($_POST['start']) : '';
	
	$plugindir=__TYPECHO_ROOT_DIR__.__TYPECHO_PLUGIN_DIR__."/";
	
	if($hasLogin==1){
		if($start==1){
			$zip = new ZipFolder;
			$arr=$zip->getFile($url,$plugindir,basename($url),1);
			if($arr){
				$result=$zip->unzip($plugindir.basename($url),$plugindir);
				if($result){
					$arr=array("code"=>100,"msg"=>"安装成功");
				}else{
					$arr=array("code"=>105,"msg"=>"安装失败，可再重试一次。");
				}
				@unlink($plugindir.basename($url));
				$db->query("update ".$prefix."contents set viewsNum=viewsNum+1 where cid=".$cid);
			}else{
				$arr=array("code"=>104,"msg"=>"下载失败");
			}
		}else{
			if(is_dir($plugindir.basename($url,".zip"))){
				$arr=array("code"=>102,"msg"=>"插件已存在");
			}else{
				$arr=array("code"=>103,"msg"=>"确定要下载吗？");
			}
		}
	}else{
		$arr=array("code"=>101,"msg"=>"登陆后获得该权限");
	}
	foreach ( $arr as $key => $value ) {  
		$arr[$key] = urlencode ( $value );  
	}  
	$json=json_encode($arr);
	echo urldecode($json);
}
?>