<?php 
$version=file_get_contents('https://www.tongleer.com/api/interface/TypechoStore.php?action=update&version=3');
echo $version;
?>