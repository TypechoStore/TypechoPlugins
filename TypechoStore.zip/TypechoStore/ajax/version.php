<?php 
$version=file_get_contents('https://tongleer.com/api/interface/TypechoStore.php?action=update&version=1');
echo $version;
?>