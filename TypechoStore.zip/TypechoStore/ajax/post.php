<?php
date_default_timezone_set('Asia/Shanghai');
include '../../../../config.inc.php';

$db = Typecho_Db::get();
$prefix = $db->getPrefix();
$options = Typecho_Widget::widget('Widget_Options');
$option=$options->plugin('TypechoStore');

$action = isset($_POST['action']) ? addslashes($_POST['action']) : '';

$res=post($action);
echo $res;

function post($action){
	$data=array(
		"action"=>$action
	);
	$url = 'http://joke.tongleer.com/api/shop.php';
	$client = Typecho_Http_Client::get();
	if ($client) {
		$str = "";
		foreach ( $data as $key => $value ) { 
			$str.= "$key=" . urlencode( $value ). "&" ;
		}
		$data = substr($str,0,-1);
		$client->setData($data)
			->setTimeout(30)
			->send($url);
		$status = $client->getResponseStatus();
		$rs = $client->getResponseBody();
		return $rs;
	}
	return 0;
}
?>