<?php
date_default_timezone_set('Asia/Shanghai');
include '../../../../config.inc.php';

$db = Typecho_Db::get();
$prefix = $db->getPrefix();
$options = Typecho_Widget::widget('Widget_Options');
$option=$options->plugin('TypechoStore');

$action = isset($_POST['action']) ? addslashes($_POST['action']) : '';
$searchvalue = isset($_POST['searchvalue']) ? addslashes($_POST['searchvalue']) : '';
$page_now = isset($_POST['page_now']) ? addslashes($_POST['page_now']) : '';

$res=post($action,$searchvalue,$page_now);
echo $res;

function post($action,$searchvalue,$page_now){
	$data=array(
		"action"=>$action,
		"searchvalue"=>$searchvalue,
		"page_now"=>$page_now
	);
	$url = 'https://www.tongleer.com/joke/api/shop.php';
	$client = Typecho_Http_Client::get();
	if ($client) {
		$str = "";
		foreach ( $data as $key => $value ) { 
			$str.= "$key=" . urlencode( $value ). "&" ;
		}
		$data = substr($str,0,-1);
		$client->setData($data)
			->setTimeout(30)
			->send($url);
		$status = $client->getResponseStatus();
		$rs = $client->getResponseBody();
		return $rs;
	}
	return 0;
}
?>