<?php
/*应用商店页面*/
include 'common.php';
define("SHOPAPI","http://joke.tongleer.com/api/shop.php");
$db = Typecho_Db::get();
$prefix = $db->getPrefix();
$options = Typecho_Widget::widget('Widget_Options');
$option=$options->plugin('TypechoStore');
$plug_url = $options->pluginUrl;
$page = isset($_GET['page']) ? addslashes($_GET['page']) : '';

$queryUser= $db->select()->from('table.users')->where('uid = ?', Typecho_Cookie::get('__typecho_uid')); 
$rowUser = $db->fetchRow($queryUser);
if($rowUser["group"]!="administrator"){return;}

?>
<?php include "shop_header.php";?>
  <!-- sidebar start -->
  <?php include "shop_sidebar.php";?>
  <!-- sidebar end -->

  <!-- content start -->
  <?php
  if($page==""){
	include "shop_index.php";
  }else if($page=="templates"){
	include "shop_templates.php";
  }else if($page=="plugins"){
	include "shop_plugins.php";
  }else{
	include "shop_404.php";
  }
  ?>
<?php include "shop_footer.php";?>