    <footer class="admin-content-footer">
      <hr>
      <p class="am-padding-left">&copy; 2018-2019 <a href="<?=$options ->siteUrl();?>" target="_blank"><?php $options->title();?></a> and Powered by <a href="http://www.tongleer.com" target="_blank">同乐儿</a>. All rights reserved.</p>
    </footer>

  </div>
  <!-- content end -->

</div>

<a href="#" class="am-icon-btn am-icon-th-list am-show-sm-only admin-menu" data-am-offcanvas="{target: '#admin-offcanvas'}"></a>

<footer>
  <hr>
  <p class="am-padding-left">&copy; 2018-2019 <a href="<?=$options ->siteUrl();?>" target="_blank"><?php $options->title();?></a> and Powered by <a href="http://www.tongleer.com" target="_blank">同乐儿</a>. All rights reserved.</p>
</footer>

<!--[if lt IE 9]>
<script src="https://apps.bdimg.com/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="https://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/amazeui/2.7.2/js/amazeui.ie8polyfill.min.js"></script>
<![endif]-->

<!--[if (gte IE 9)|!(IE)]><!-->
<script src="https://apps.bdimg.com/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<!--<![endif]-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/layer/2.3/layer.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/amazeui/2.7.2/js/amazeui.min.js" type="text/javascript"></script>
<script src="<?=Helper::options()->pluginUrl;?>/TypechoStore/js/app.js"></script>
</body>
</html>