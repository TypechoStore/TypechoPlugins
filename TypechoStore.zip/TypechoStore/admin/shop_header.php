<!doctype html>
<html class="no-js">
<head lang="zh">
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Typecho应用商店</title>
  <meta name="description" content="Typecho应用商店为用户提供快捷安装Typecho模板、插件的渠道。">
  <meta name="keywords" content="Typecho,Typecho应用商店">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="renderer" content="webkit">
  <meta name="format-detection" content="telephone=no">
  <meta http-equiv="Cache-Control" content="no-siteapp" />
  <meta name="author" content="二呆">
  <link rel="icon" type="image/png" href="assets/i/favicon.png">
  <link rel="apple-touch-icon-precomposed" href="assets/i/app-icon72x72@2x.png">
  <meta name="apple-mobile-web-app-title" content="Amaze UI" />
  <link rel="alternate icon" href="https://ws3.sinaimg.cn/large/ecabade5ly1fy0sa19c85j200s00s744.jpg" type="image/png" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/amazeui/2.7.2/css/amazeui.min.css"/>
  <link rel="stylesheet" href="<?=Helper::options()->pluginUrl;?>/TypechoStore/css/admin.css">
  <script src="https://apps.bdimg.com/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
</head>
<body>
<!--[if lte IE 9]>
<p class="browsehappy">你正在使用<strong>过时</strong>的浏览器，Amaze UI 暂不支持。 请 <a href="http://browsehappy.com/" target="_blank">升级浏览器</a>
  以获得更好的体验！</p>
<![endif]-->
<header class="am-topbar am-topbar-inverse admin-header">
  <div class="am-topbar-brand">
    <strong><a href="<?php $options->siteUrl(); ?><?php echo substr(__TYPECHO_ADMIN_DIR__,1);?>">Typecho应用商店</a></strong> <small>安装快捷通道</small>
  </div>

  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>

  <div class="am-collapse am-topbar-collapse" id="topbar-collapse">

    <ul class="am-nav am-nav-pills am-topbar-nav am-topbar-right admin-header-list">
      <li><a href="<?php $options->siteUrl(); ?>" target="_blank"><span class="am-icon-home"></span> 网站 </a></li>
	  <?php if($user->hasLogin()){?>
	  <li class="am-dropdown" data-am-dropdown>
        <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;" title="<?php
			if ($user->logged > 0) {
				$logged = new Typecho_Date($user->logged);
				_e('最后登录: %s', $logged->word());
			}
		?>">
          <span class="am-icon-users"></span> <?php $user->screenName(); ?> <span class="am-icon-caret-down"></span>
        </a>
        <ul class="am-dropdown-content">
          <li><a href="<?php $options->adminUrl('profile.php'); ?>"><span class="am-icon-user"></span> 资料</a></li>
          <li><a href="<?php $options->logoutUrl(); ?>"><span class="am-icon-power-off"></span> 退出</a></li>
        </ul>
      </li>
	  <?php }else{?>
	  <li><a href="<?php $options->siteUrl(); ?><?php echo substr(__TYPECHO_ADMIN_DIR__,1);?>"><span class="am-icon-users"></span> 登录 </a></li>
	  <?php }?>
      <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
    </ul>
  </div>
</header>

<div class="am-cf admin-main">