<div class="admin-sidebar am-offcanvas" id="admin-offcanvas">
    <div class="am-offcanvas-bar admin-offcanvas-bar">
      <ul class="am-list admin-sidebar-list">
        <li><a href="<?php $options->siteUrl(); ?><?php echo substr(__TYPECHO_ADMIN_DIR__,1);?>shop.php"><span class="am-icon-home"></span> 首页</a></li>
        <li class="admin-parent">
          <a class="am-cf" data-am-collapse="{target: '#collapse-nav'}"><span class="am-icon-file"></span> 商店 <span class="am-icon-angle-right am-fr am-margin-right"></span></a>
          <ul class="am-list am-collapse admin-sidebar-sub am-in" id="collapse-nav">
			<li><a href="<?php $options->siteUrl(); ?><?php echo substr(__TYPECHO_ADMIN_DIR__,1);?>shop.php?page=templates"><span class="am-icon-th"></span> Typecho模板</a></li>
            <li><a href="<?php $options->siteUrl(); ?><?php echo substr(__TYPECHO_ADMIN_DIR__,1);?>shop.php?page=plugins"><span class="am-icon-puzzle-piece"></span> Typecho插件</a></li>
          </ul>
        </li>
      </ul>
	  
	  <div class="am-panel am-panel-default admin-sidebar-panel">
        <!--
		<div class="am-panel-bd">
          <p><span class="am-icon-tag"></span> 一言</p>
          <p></p>
        </div>
		-->
		<img src="https://tongleer.com/api/web/?action=img" width="100%" alt="" />
      </div>

      <div class="am-panel am-panel-default admin-sidebar-panel">
        <div class="am-panel-bd">
          <p><span class="am-icon-bookmark"></span> 介绍</p>
          <p>
			<small>
			感谢您使用Typecho应用商店<br />
			<a href="http://joke.tongleer.com" target="_blank">官方网站</a>&nbsp;
			<a href="http://joke.tongleer.com/publishapp.html" target="_blank">发布应用</a>&nbsp;
			<a href="http://club.tongleer.com" target="_blank">交流论坛</a>
			</small>
		  </p>
        </div>
      </div>
      
    </div>
</div>