<div class="admin-content">

    <div class="admin-content-body">
      <div class="am-cf am-padding am-padding-bottom-0">
        <div class="am-fl am-cf">
          <strong class="am-text-primary am-text-lg">主题</strong> / <small>Typecho模板</small>
        </div>
		<div class="am-u-sm-12 am-u-md-3 am-fr">
		<form method="get" action="">
          <div class="am-input-group am-input-group-sm">
            <input type="text" name="searchkey" class="am-form-field">
          <span class="am-input-group-btn">
            <button class="am-btn am-btn-default" type="submit">搜索</button>
			<input type="hidden" name="page" value="templates">
			<input type="hidden" id="searchvalue" value="<?=@$_GET["searchkey"];?>">
          </span>
          </div>
		</form>
        </div>
      </div>

      <hr>

      <ul id="templateList" class="am-avg-sm-2 am-avg-md-4 am-avg-lg-6 am-margin gallery-list"></ul>
	  
	  <div class="am-modal am-modal-no-btn" tabindex="-1" id="template_popup">
		  <div class="am-modal-dialog">
			<div class="am-modal-hd"><span id="templates_popup_title"></span>
			  <a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a>
			</div>
			<div class="am-modal-bd" style="height:300px;overflow-y:scroll;">
			  <div id="templates_popup_text"></div>
			</div>
			<?php if($user->hasLogin()){?>
			<input type="hidden" id="hasLogin" value="<?=$user->hasLogin();?>" />
			<?php }?>
			<a id="templates_popup_demo" type="button" class="am-btn am-btn-success am-radius" target="_blank" rel="nofollow">演示地址</a>
			<?php
			$queryUser= $db->select()->from('table.users')->where('uid = ?', Typecho_Cookie::get('__typecho_uid')); 
			$rowUser = $db->fetchRow($queryUser);
			if($rowUser["group"]=="administrator"){
			?>
			<input type="hidden" id="hasAdmin" value="1" />
			<?php
			}
			?>
			<a id="templates_popup_download" type="button" class="am-btn am-btn-warning am-radius" target="_blank" rel="nofollow">下载地址</a>
		  </div>
	  </div>
	  
      <div class="am-margin am-cf">
        <hr/>
        <p class="am-fl">共 <span id="totalItemId">0</span> 条记录</p>
      </div>
	  <div class="am-margin am-cf" id="pageBar"><!--这里添加分页按钮栏--></div>
    </div>
	<script>
	var curPage;/*当前页数*/
	var totalItem;/*总记录数*/
	var pageSize;/*每一页记录数*/
	var totalPage;/*总页数*/
	//获取分页数据
	function turnPage(page,searchvalue){
		$.ajax({
			type : "POST",
			url : "<?=$plug_url;?>/TypechoStore/ajax/post.php",
			data : {"action":"templateList","page_now":page,"searchvalue":searchvalue},
			dataType : 'json',
			beforeSend: function() {
				$("#templateList").append("加载中...");
			},
			success : function(data) {
				$("#templateList").empty();/*移除原来的分页数据*/
				totalItem = data.totalItem;
				pageSize = data.pageSize;
				curPage = page;
				totalPage = data.totalPage;
				$("#totalItemId").html(totalItem);
				$.each(data.result,function(index,array) {
					var templatesLi='<li><a id="templatesPage'+array.cid+'" class="templatesPage" data-cid="'+array.cid+'" data-text="'+array.text+'" data-demo="'+array.demourl+'" data-github="'+array.githuburl+'" data-qq="'+array.qq+'" data-charge="'+array.ischarge+'" data-price="'+array.price+'" data-version="'+array.version+'" href="javascript:;"  title=""><div style="height:150px;max-height:150px;overflow:hidden;"><img style="height:150px;width:150px;" class="am-img-thumbnail am-img-bdrs" src="'+array.thumbnail+'" alt="'+array.title+'"/></div><div class="gallery-title">'+array.title+'</div></a><div class="gallery-desc"><a href="https://wpa.qq.com/msgrd?v=3&uin='+array.qq+'&site=qq&menu=yes" target="_blank" rel="nofollow"><img src="https://q4.qlogo.cn/headimg_dl?dst_uin='+array.qq+'&spec=100" width="20" /></a> <span>上架于</span> <span>'+array.date+'</span></div></li>';
					$("#templateList").append(templatesLi);
				});
				$(".templatesPage").each(function(){
					var id=$(this).attr("id");
					$("#"+id).click( function () {
						$("#templates_popup_title").html($("#"+id+" .gallery-title").html()+"V"+$(this).attr("data-version"));
						$("#templates_popup_text").html($(this).attr("data-text"));
						$("#templates_popup_demo").attr("href",$(this).attr("data-demo"));
						if($(this).attr("data-charge")=="y"){
							$("#templates_popup_download").attr("href","https://wpa.qq.com/msgrd?v=3&uin="+$(this).attr("data-qq")+"&site=qq&menu=yes");
							$("#templates_popup_download").html("花"+$(this).attr("data-price")+"元购买");
						}else{
							if($("#hasAdmin").val()==1){
								$("#templates_popup_download").attr("href","javascript:download('downloadTemplate','"+$(this).attr("data-cid")+"','"+$(this).attr("data-github")+"');");
							}else{
								$("#templates_popup_download").attr("href",$(this).attr("data-github"));
							}
							$("#templates_popup_download").html("免费下载");
						}
						$("#template_popup").modal('toggle');
					});
				});
				getPageBar(searchvalue);
			},complete: function() {/*添加分页按钮栏*/
			  if(totalItem==0){
				  $("#pageBar").html("");
			  }
			},error:function(data){
				layer.msg("数据加载失败");
			}
		});
	}
	/*获取分页条（分页按钮栏的规则和样式根据自己的需要来设置）*/
	function getPageBar(searchvalue){
	  if(curPage > totalPage) {
		curPage = totalPage;
	  }
	  if(curPage < 1) {
		curPage = 1;
	  }
	  pageBar = "<ul class=\"am-pagination blog-pagination\">";
	  /*如果不是第一页*/
	  if(curPage != 1){
		pageBar += "<li class=\"am-pagination-prev\"><a href=\"javascript:turnPage(1,'"+searchvalue+"')\">首页</a></li>";
		pageBar += "<li class=\"am-pagination-prev\"><a href=\"javascript:turnPage("+(curPage-1)+",'"+searchvalue+"')\"><<</a></li>";
	  }
	  /*显示的页码按钮(5个)*/
	  var start,end;
	  if(totalPage <= 5) {
		start = 1;
		end = totalPage;
	  } else {
		if(curPage-2 <= 0) {
			start = 1;
			end = 5;
		} else {
			if(totalPage-curPage < 2) {
				start = totalPage - 4;
				end = totalPage;
			} else {
				start = curPage - 2;
				end = curPage + 2;
			}
		}
	  }
	  for(var i=start;i<=end;i++) {
		if(i == curPage) {
			pageBar += "<li class=\"am-active\"><a href=\"javascript:turnPage("+i+",'"+searchvalue+"')\">"+i+"</a></li>";
		} else {
			pageBar += "<li><a href=\"javascript:turnPage("+i+",'"+searchvalue+"')\">"+i+"</a></li>";
		}
	  }
	  /*如果不是最后页*/
	  if(curPage != totalPage){
		pageBar += "<li class=\"am-pagination-next\"><a href=\"javascript:turnPage("+(parseInt(curPage)+1)+",'"+searchvalue+"')\">>></a></li>";
		pageBar += "<li class=\"am-pagination-next\"><a href=\"javascript:turnPage("+totalPage+",'"+searchvalue+"')\">尾页</a></li>";
	  }
		pageBar += "</ul>"; 
	  $("#pageBar").html(pageBar);
	}
	/*页面加载时初始化分页*/
	turnPage(1,$("#searchvalue").val());
	function download(action,cid,url){
		$.ajax({
			type : "POST",
			url : "<?=$plug_url;?>/TypechoStore/ajax/download.php",
			data : {"action":action,"cid":cid,"url":url,"hasLogin":$("#hasLogin").val()},
			dataType : 'json',
			success : function(data) {
				if(data.code==101){
					layer.msg(data.msg);
				}else if(data.code==102){
					layer.confirm(data.msg, {
						btn: ['覆盖','取消']
					},function(index){
						var load = layer.load(2, {shade:[0.1,'#fff']});
						$.post("<?=$plug_url;?>/TypechoStore/ajax/download.php",{action:action,"cid":cid,"url":url,"hasLogin":$("#hasLogin").val(),start:1},function(data){
							layer.close(load);
							var data=JSON.parse(data);
							if(data.code==100){
								layer.msg(data.msg);
							}else{
								layer.msg(data.msg);
							}
						});
						layer.close(index);
					});
				}else if(data.code==103){
					layer.confirm(data.msg, {
						btn: ['下载','取消']
					},function(index){
						var load = layer.load(2, {shade:[0.1,'#fff']});
						$.post("<?=$plug_url;?>/TypechoStore/ajax/download.php",{action:action,"cid":cid,"url":url,"hasLogin":$("#hasLogin").val(),start:1},function(data){
							layer.close(load);
							var data=JSON.parse(data);
							if(data.code==100){
								layer.msg(data.msg);
							}else{
								layer.msg(data.msg);
							}
						});
						layer.close(index);
					});
				}
			},error:function(data){
				layer.msg("下载出错");
			}
		});
	}
	</script>