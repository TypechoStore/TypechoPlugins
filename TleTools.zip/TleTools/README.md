### Typecho同乐工具集插件
---

Typecho同乐工具集插件，一个可添加本地、网络工具，并支持开发者提交收费、免费工具到工具市场和设置首页后“相当于”模板使用，随意从工具和分类中切换的工具集插件。

程序有可能会遇到bug不改版本号直接修改代码的时候，所以扫描以下二维码关注公众号“同乐儿”，可直接与作者二呆产生联系，不再为bug烦恼，随时随地解决问题。

<img src="http://me.tongleer.com/content/uploadfile/201706/008b1497454448.png">

#### 使用方法：
第一步：下载本插件，放在 `usr/plugins/` 目录中（插件文件夹名必须为TleTools）；<br />
第二步：激活插件；<br />
第三步：填写配置；<br />
第四步：完成。

#### 版本推荐：
php+mysql，推荐php5.6，以上版本可能也没问题，如有问题可联系作者。

#### 与我联系：
作者：二呆<br />
网站：http://www.tongleer.com/<br />
Github：https://github.com/muzishanshi/TleToolsForTypecho

#### 更新记录：
2018-24-24
	
	V1.0.1 发布