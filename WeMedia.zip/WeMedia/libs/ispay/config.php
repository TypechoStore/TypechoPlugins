<?php
$config = array (
         //商户ID(payId)
		'payId' => "",

         //商户密钥(payKey)
		'payKey' => "",
);
?>