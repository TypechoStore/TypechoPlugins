<hr>
<footer class="admin-content-footer">
  <p class="am-padding-left">
	<small>CopyRight©2018 <a href="<?=$this->options ->siteUrl();?>"><?php $this->options->title();?></a></small>
  </p>
</footer>