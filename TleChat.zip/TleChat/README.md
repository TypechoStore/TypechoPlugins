### TleChatForTypecho站长聊天室插件
---

站长聊天室插件为Typecho站长提供聊天室功能，让站长之间的联系更加友爱，支持文本、长文本、语音聊天、图片传输及站长之间的QQ、微信、支付宝打赏，共同建立一个友爱的站长联盟。

#### 使用方法：
第一步：下载本插件，放在 `usr/plugins/` 目录中（插件文件夹名必须为TleChat）；<br />
第二步：激活插件；<br />
第三步：填写配置；<br />
第四步：完成。

#### 与我联系：
作者：二呆<br />
网站：http://www.tongleer.com/<br />
1元入群：http://joke.tongleer.com/331.html<br />
Typecho版本的聊天室Github：https://github.com/muzishanshi/TleChatForTypecho<br />
Emlog版本的聊天室Github：https://github.com/muzishanshi/TleChatForEmlog<br />
Wordpress版本的聊天室Github：https://github.com/muzishanshi/TleChatForWordpress

#### 更新记录：
2018-11-06

	V1.0.1	第一版本实现