#### TleCollectForTypecho采集插件

TleCollectForTypecho采集插件是一个使用QueryList采集工具的Typecho采集插件，由同乐儿因兴趣将以前的功能开发成插件，仅供学习、娱乐之用，不确保所有网站都能采集，但填写好网站源代码中适合的选择器后可正常采集一般网站，现已屏蔽多篇采集和优酷视频多篇采集，请知悉。

#### 使用方法：
第一步：下载本插件，放在 `usr/plugins/` 目录中（插件文件夹名必须为TleCollect）；

第二步：激活插件；

第三步：填写配置；

第四步：完成。

#### 版本推荐
php5.6+Typecho正式版

#### 下载地址
Github：https://github.com/muzishanshi/TleCollectForTypecho

#### 版本记录
2019-04-24 V1.0.1

	第一个版本降世